#ifndef EVCAR_H
#define EVCAR_H

#include "EvCarType.h"
#include <ostream>

class EvCar
{
private:
    /* data */
    float _battery_capacity;
    float _price;
    EvCarType _charging_type;

public:
    EvCar() = default;                        // disabled default constructor
    EvCar(const EvCar &) = delete;            // disabled copy constructor
    EvCar &operator=(const EvCar &) = delete; // disabled copy assignment
    EvCar &operator=(EvCar &&) = delete;      // enabled move assignment
    EvCar(EvCar &&) = delete;                 // disabled move constructor
    ~EvCar() = default;

    EvCar(float battery_capacity,
          float price,
          EvCarType charging_type);

    float batteryCapacity() const { return _battery_capacity; }

    float price() const { return _price; }

    EvCarType chargingType() const { return _charging_type; }
    void setChargingType(const EvCarType &charging_type) { _charging_type = charging_type; }

    float CalculateGst();

    friend std::ostream &operator<<(std::ostream &os, const EvCar &rhs);
};

#endif // EVCAR_H
