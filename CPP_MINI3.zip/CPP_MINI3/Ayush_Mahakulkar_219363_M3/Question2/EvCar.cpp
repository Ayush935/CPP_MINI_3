#include "EvCar.h"
std::ostream &operator<<(std::ostream &os, const EvCar &rhs) {
    std::string val = "";
    if(rhs._charging_type==EvCarType::AC){
        val = "AC";
    }
    else if(rhs._charging_type==EvCarType::BOTH){
        val = "BOTH";
    }
    else{
        val = "DC";
    }
    os << "_battery_capacity: " << rhs._battery_capacity
       << " _price: " << rhs._price
       << " _charging_type: " << val;
    return os;
}

EvCar::EvCar(float battery_capacity, float price, EvCarType charging_type)
    : _battery_capacity{battery_capacity},_price{price},_charging_type{charging_type}
{
}

float EvCar::CalculateGst()
{
    return 0.1*_price;
}
