#ifndef OPERATIONS_H
#define OPERATIONS_H

#include <variant>
#include "Automobile.h"
#include "EvCar.h"
#include <vector>
#include <memory>
#include <mutex>
#include "ContainerEmptyDataException.h"
using AutomobilePtr = std::shared_ptr<Automobile>;
using EvCarPtr = std::shared_ptr<EvCar>;
using VType = std::variant<AutomobilePtr,EvCarPtr>;
using Container = std::vector<VType>;

class Operations
{
private:
    Container m_data;
    std::mutex m1;
    Operations() = default;                        // disabled default constructor
    Operations(const Operations &) = delete;            // disabled copy constructor
    Operations &operator=(const Operations &) = delete; // disabled copy assignment
    Operations &operator=(Operations &&) = delete;      // enabled move assignment
    Operations(Operations &&) = delete;  
    static Operations* _only_object;
public:
    ~Operations() = default;
    static Operations*GetInstance();

    void CreateObjects();
    void DisplayAverageEvCarGSTAmount();
    void DisplayAutomobileSeatCountGreaterThan4();
    void DisplayAutomobileAveragePrice();
    void FindAtLeatOneEvCarHasTypeDC();
};

#endif // OPERATIONS_H
