#include "Automobile.h"
std::ostream &operator<<(std::ostream &os, const Automobile &rhs) {
    std::string val = "";
    if(rhs._type==AutomobileType::REGULAR){
        val = "REGULAR";
    }
    else{
        val = "TRANSPORT";
    }
    os << "_id: " << rhs._id
       << " _type: " << val
       << " _price: " << rhs._price
       << " _seat_count: " << rhs._seat_count
       << " _engine_horsepower: " << rhs._engine_horsepower;
    return os;
}

Automobile::Automobile(std::string id, AutomobileType type, float price, int seat_count, int engine_horsepower)
    : _id{id},_type{type},_price{price},_seat_count{seat_count},_engine_horsepower{engine_horsepower}
{
}

float Automobile::CalculatGst()
{
    return 0.18*_price;
}
