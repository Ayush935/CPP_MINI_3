#include "Operations.h"
#include <thread>

int main(){
    Operations *ptr = Operations::GetInstance();
    ptr->CreateObjects();
   
    std::thread t1(&Operations::DisplayAutomobileAveragePrice,ptr);
    std::thread t2(&Operations::DisplayAutomobileSeatCountGreaterThan4,ptr);
    std::thread t3(&Operations::DisplayAverageEvCarGSTAmount,ptr);
    std::thread t4(&Operations::FindAtLeatOneEvCarHasTypeDC,ptr);

    if(t1.joinable()){
        t1.join();
    }
    if(t2.joinable()){
        t2.join();
    }
    if(t3.joinable()){
        t3.join();
    }
    if(t4.joinable()){
        t4.join();
    }
    
    
}