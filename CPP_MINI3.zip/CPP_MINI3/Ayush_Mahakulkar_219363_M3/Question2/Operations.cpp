#include "Operations.h"

Operations* Operations::_only_object{nullptr};

Operations *Operations::GetInstance()
{
    if(_only_object){
        return _only_object;
    }
    else{
        _only_object = new Operations();
        return _only_object;
    }
}

void Operations::CreateObjects()
{
   

    m_data.emplace_back(std::make_shared<Automobile>("MH123",AutomobileType::REGULAR,50000.0f,5,50));
    m_data.emplace_back(std::make_shared<Automobile>("MH124",AutomobileType::TRANSPORT,150000.0f,2,100));
    m_data.emplace_back(std::make_shared<Automobile>("MH125",AutomobileType::REGULAR,250000.0f,3,90));
    m_data.emplace_back(std::make_shared<EvCar>(1200.4f,100000.0f,EvCarType::AC));
    m_data.emplace_back(std::make_shared<EvCar>(1400.4f,10000.0f,EvCarType::DC));
}

void Operations::DisplayAverageEvCarGSTAmount()
{
    if(m_data.empty()){
        throw ContainerEmptyException("Data is empty");
    }
    float sum{0.0f};
    float value{0.0f};
    int count{0};
    for(VType v : m_data){
        if(std::holds_alternative<EvCarPtr>(v)){
          sum += std::get<EvCarPtr>(v)->CalculateGst();
          count++;
       }
       
    };
    std::lock_guard<std::mutex>lk(m1);count++;
    std::cout<<"Average of EVCar GST Amount "<< sum/static_cast<float>(count)<<std::endl;
}

void Operations::DisplayAutomobileSeatCountGreaterThan4()
{
    if(m_data.empty()){
        throw ContainerEmptyException("Data is empty");
    }
    AutomobilePtr ptr;
    std::vector<AutomobilePtr> vtype;
    int seatCount = 4;
    for(VType v : m_data){
        if(std::holds_alternative<AutomobilePtr>(v)){
          if(seatCount<=std::get<AutomobilePtr>(v)->seatCount()){
                 vtype.push_back(std::get<AutomobilePtr>(v));
          }
         
       }
       
    };
    if(vtype.empty()){
        throw ContainerEmptyException("Data is empty");
    }
    std::lock_guard<std::mutex>lk(m1);
    std::cout<<"SeatCount Greater Than 5"<<std::endl;
    for(AutomobilePtr v: vtype){
         std::cout<<*v<<std::endl;
    }
}

void Operations::DisplayAutomobileAveragePrice()
{
    if(m_data.empty()){
        throw ContainerEmptyException("Data is empty");
    }
     float sum{0.0f};
   
    int count{0};
    for(VType v : m_data){
        if(std::holds_alternative<AutomobilePtr>(v)){
          sum += std::get<AutomobilePtr>(v)->price();
          count++;
       }
       
    };

    std::lock_guard<std::mutex>lk(m1);
    std::cout<<"Average prices of Automobiles are "<<sum/static_cast<float>(count)<<std::endl;
}

void Operations::FindAtLeatOneEvCarHasTypeDC()
{
    if(m_data.empty()){
        throw ContainerEmptyException("Data is empty");
    }

    bool flag{false};
    EvCarType type;
    for(VType v : m_data){
        if(std::holds_alternative<EvCarPtr>(v)){
          type = std::get<EvCarPtr>(v)->chargingType();
          if(type == EvCarType::DC){
            flag = true;
            break;
          }
       }
       
    };
    if(flag){
        std::lock_guard<std::mutex>lk(m1);
        std::cout<<"EvCar Has Charging Type DC"<<std::endl;
    }
}
