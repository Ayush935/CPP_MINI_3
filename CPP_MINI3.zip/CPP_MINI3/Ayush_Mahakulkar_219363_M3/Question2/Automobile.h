#ifndef AUTOMOBILE_H
#define AUTOMOBILE_H

#include <iostream>
#include "AutomobileType.h"

class Automobile
{
private:
    /* data */
    std::string _id;
    AutomobileType _type;
    float _price;
    int _seat_count;
    int _engine_horsepower;

public:
    Automobile() = default;                             // disabled default constructor
    Automobile(const Automobile &) = delete;            // disabled copy constructor
    Automobile &operator=(const Automobile &) = delete; // disabled copy assignment
    Automobile &operator=(Automobile &&) = delete;      // enabled move assignment
    Automobile(Automobile &&) = delete;                 // disabled move constructor
    ~Automobile() = default;

    Automobile(std::string id,
               AutomobileType type,
               float price,
               int seat_count,
               int engine_horsepower);

    float CalculatGst();

    std::string id() const { return _id; }

    AutomobileType type() const { return _type; }
    void setType(const AutomobileType &type) { _type = type; }

    float price() const { return _price; }
    void setPrice(float price) { _price = price; }

    int seatCount() const { return _seat_count; }

    int engineHorsepower() const { return _engine_horsepower; }

    friend std::ostream &operator<<(std::ostream &os, const Automobile &rhs);
};

#endif // AUTOMOBILE_H
