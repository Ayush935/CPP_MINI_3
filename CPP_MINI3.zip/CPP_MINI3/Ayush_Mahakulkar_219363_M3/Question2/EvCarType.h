#ifndef EVCARTYPE_H
#define EVCARTYPE_H

enum class EvCarType
{
    DC,
    AC,
    BOTH
};

#endif // EVCARTYPE_H
