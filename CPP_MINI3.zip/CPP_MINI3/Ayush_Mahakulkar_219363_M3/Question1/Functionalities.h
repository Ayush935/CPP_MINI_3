#include <vector>
#include <functional>
#include "ContainerEmptyDataException.h"
#include "InValidSizeException.h"
using Container = std::vector<int>;
using CharContainer = std::array<char,20>;
using StringContainer = std::vector<std::string>;

/*
  Sum of first 3 integers in container
*/
int SumOfFirst3Integers(const Container &data);

/*
  Minimum among the last 3 numbers
*/
int MinimumFromLast3Integers(const Container &data);

/*
  Prime numbers among the Container
*/
std::optional<Container> PrimeNumbersContainer(const Container&data);

/*
  Return Numbers divisible by 2
*/
std::optional<Container> NumberDivisibleBy2Container(const Container& data, std::function<bool(int value)>fns);

/*
  Return string with Max Characters
*/
std::string MaximumCharactersInString(const StringContainer& data);

/*
  Return Container with Non vowel Characters
*/
std::optional<CharContainer> NonVowelCharacters(const StringContainer& data);



