#include "Functionalities.h"
#include <future>
#include <iostream>

int main(){
    Container data{1,2,3,4,5};
    StringContainer stringData{"Ayush","Bob","Bobby","Jack","John"};

    std::future<int> SumIntegers = std::async(&SumOfFirst3Integers,std::ref(data));
    std::future<int> MinimumNumber = std::async(&MinimumFromLast3Integers,std::ref(data));
    std::future<std::optional<Container>> PrimeNumbers = std::async(&PrimeNumbersContainer,std::ref(data));
    std::future<std::optional<Container>> NumberDivisible = std::async(&NumberDivisibleBy2Container,std::ref(data),[](int val){return val%2==0;});
    std::future<std::string> MaxCharacters = std::async(&MaximumCharactersInString,std::ref(stringData));
    std::future<std::optional<CharContainer>> NonVowels = std::async(&NonVowelCharacters,std::ref(stringData));

    try
    {
        
        int Sum = SumIntegers.get();
        std::cout<<"Sum of First thre integers is "<<Sum<<std::endl;

        int Min = MinimumNumber.get();
        std::cout<<"SMinimum Number from Last 3 integers is "<<Min<<std::endl;

        std::optional<Container> prime = PrimeNumbers.get();
        if(prime.has_value()){
           Container primeNum = prime.value();
           std::cout<<"Prime Numbers in Container are ";
           for(int val: primeNum){
            std::cout<<val<<" ";
           }
           std::cout<<std::endl;
        }
        else{
            std::cout<<"No Prime Numbers found"<<std::endl;
        }

        std::optional<Container> num = NumberDivisible.get();
        if(num.has_value()){
           Container numbers = num.value();
           std::cout<<"Numbers Divisible by 2 are ";
           for(int val: numbers){
            std::cout<<val<<" ";
           }
            std::cout<<std::endl;
        }
        else{
            std::cout<<"No members divisible by 2 found"<<std::endl;
        }

        std::string MaxString = MaxCharacters.get();
        std::cout<<"Maximum Length String is "<<MaxString<<std::endl;

        std::optional<CharContainer> nonVowel = NonVowels.get();
        if(nonVowel.has_value()){
            CharContainer values = nonVowel.value();
            std::cout<<"Non vowels Character are as follows ";
            for(int i=0;i<values.size();i++){
                std::cout<<values[i]<<" ";
            }
            std::cout<<std::endl;
        }
        else{
            std::cout<<"No vowels Found"<<std::endl;
        }
    }
    catch(ContainerEmptyException &e)
    {
        std::cerr << e.what() << '\n';
    }
    catch(InValidSizeException &e)
    {
        std::cerr << e.what() << '\n';
    }
    
}