#ifndef INVALIDSIZEEXCEPTION_H
#define INVALIDSIZEEXCEPTION_H

#include <stdexcept>
#include <future>

class InValidSizeException : public std::future_error
{
private:
    std::string _msg;

public:
    InValidSizeException(std::string msg,std::future_errc ec) : _msg(msg),std::future_error(ec) {}
    InValidSizeException() = default;                                          // disabled default constructor
    InValidSizeException(const InValidSizeException &) = delete;            // disabled copy constructor
    InValidSizeException &operator=(const InValidSizeException &) = delete; // disabled copy assignment
    InValidSizeException &operator=(InValidSizeException &&) = default;     // enabled move assignment
    InValidSizeException(InValidSizeException &&) = delete;                 // disabled move constructor
    ~InValidSizeException() = default;                                         // disabled default destructor
    std::string what() { return _msg; }                                           // getter for _msg!
};


#endif // INVALIDSIZEEXCEPTION_H
