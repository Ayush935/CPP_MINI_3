#ifndef CONTAINEREMPTYEXCEPTION_H
#define CONTAINEREMPTYEXCEPTION_H

#include <stdexcept>
#include <future>

class ContainerEmptyException : public std::future_error
{
private:
    std::string _msg;

public:
    ContainerEmptyException(std::string msg,std::future_errc ec) : _msg(msg),std::future_error(ec) {}
    ContainerEmptyException() = default;                                          // disabled default constructor
    ContainerEmptyException(const ContainerEmptyException &) = delete;            // disabled copy constructor
    ContainerEmptyException &operator=(const ContainerEmptyException &) = delete; // disabled copy assignment
    ContainerEmptyException &operator=(ContainerEmptyException &&) = default;     // enabled move assignment
    ContainerEmptyException(ContainerEmptyException &&) = delete;                 // disabled move constructor
    ~ContainerEmptyException() = default;                                         // disabled default destructor
    std::string what() { return _msg; }                                           // getter for _msg!
};

#endif // CONTAINEREMPTYEXCEPTION_H


/*
  #ifndef CONTAINEREMPTYEXCEPTION_H
#define CONTAINEREMPTYEXCEPTION_H

#include <stdexcept>

class ContainerEmptyException : std::exception
{
private:
    std::string _msg;

public:
    ContainerEmptyException(std::string msg) : _msg(msg) {}
    ContainerEmptyException() = default;                                          // disabled default constructor
    ContainerEmptyException(const ContainerEmptyException &) = delete;            // disabled copy constructor
    ContainerEmptyException &operator=(const ContainerEmptyException &) = delete; // disabled copy assignment
    ContainerEmptyException &operator=(ContainerEmptyException &&) = default;     // enabled move assignment
    ContainerEmptyException(ContainerEmptyException &&) = delete;                 // disabled move constructor
    ~ContainerEmptyException() = default;                                         // disabled default destructor
    std::string what() { return _msg; }                                           // getter for _msg!
};

#endif // CONTAINEREMPTYEXCEPTION_H



*/

