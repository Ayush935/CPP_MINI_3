#include "Functionalities.h"
#include <iostream>

int SumOfFirst3Integers(const Container &data)
{
    if (data.empty())
    {
        throw ContainerEmptyException("Data is empty", std::future_errc::no_state);
    }

    if (data.size() < 3)
    {
        throw InValidSizeException("Size is invalid", std::future_errc::no_state);
    }

    int count{0};
    int sum{0};
    for (int val : data)
    {
        sum += val;
        count++;
        if (count == 3)
        {
            break;
        }
    }

    return sum;
}

int MinimumFromLast3Integers(const Container &data)
{
    if (data.empty())
    {
        throw ContainerEmptyException("Data is empty", std::future_errc::no_state);
    }

    if (data.size() < 3)
    {
        throw InValidSizeException("Size is invalid", std::future_errc::no_state);
    }

    int Min = data[data.size() - 1];
    int count{0};
    for (int i = data.size() - 1; i >= 0; i--)
    {
        if (Min > data[i])
        {
            Min = data[i];
        }
        count++;
        if (count == 3)
        {
            break;
        }
    }

    return Min;
}

std::optional<Container> PrimeNumbersContainer(const Container &data)
{
    if (data.empty())
    {
        throw ContainerEmptyException("Data is empty", std::future_errc::no_state);
    }
    int c = 0;
    bool flag{false};
    Container result;
    for (int val : data)
    {
        if (val == 2)
        {
            result.push_back(val);
        }

        for (int i = 2; i < val; i++)
        {

            if (val % i == 0)
            {
                flag = true;
                break;
            }
        }

        if (!flag)
        {
            if (val == 1 || val == 2)
            {
                c = val;
            }
            else
            {
                result.push_back(val);
            }
        }
    }

    if (result.empty())
    {
        throw std::nullopt;
    }

    return result;
}

std::optional<Container> NumberDivisibleBy2Container(const Container &data, std::function<bool(int value)> fns)
{
    if (data.empty())
    {
        throw ContainerEmptyException("Data is empty", std::future_errc::no_state);
    }

    Container result;
    for (int val : data)
    {
        if (fns(val))
        {
            result.push_back(val);
        }
    }

    if (result.empty())
    {
        throw std::nullopt;
    }

    return result;
}

std::string MaximumCharactersInString(const StringContainer &data)
{
    if (data.empty())
    {
        throw ContainerEmptyException("Data is empty", std::future_errc::no_state);
    }

    std::string ans = " ";
    int MaxSize = data[0].size();
    for (std::string val : data)
    {
        if (MaxSize < val.size())
        {
            MaxSize = val.size();
        }
    }

    for (std::string val : data)
    {
        if (val.size() == MaxSize)
        {
            ans = val;
            break;
        }
    }

    return ans;
}

std::optional<CharContainer> NonVowelCharacters(const StringContainer &data)
{
    if (data.empty())
    {
        throw ContainerEmptyException("Data is empty", std::future_errc::no_state);
    }

    CharContainer result;
    int p = 0;
    char a;

    for (std::string val : data)
    {
        for (int i = 0; i < val.size(); i++)
        {
            if (val[i] == 'a' || val[i] == 'e' || val[i] == 'i' || val[i] == 'o' || val[i] == 'u' ||
                val[i] == 'A' || val[i] == 'E' || val[i] == 'I' || val[i] == 'O' || val[i] == 'U')
            {
                a = val[i];
            }
            else
            {
                result[i] = val[i];
            }
        }
    }

    if (result.empty())
    {
        throw std::nullopt;
    }

    return result;
}
