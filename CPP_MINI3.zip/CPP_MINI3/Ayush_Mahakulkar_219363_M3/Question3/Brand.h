#ifndef BRAND_H
#define BRAND_H

#include "BrandType.h"
#include "Car.h"
#include <iostream>
#include <functional>
#include <array>
using CarRef = std::reference_wrapper<Car>;
using CarRefContainer = std::array<CarRef, 3>;

class Brand
{
private:
    /* data */
    BrandType _type;
    std::string _unique_tm;
    CarRefContainer _ref;

public:
    Brand() = default;                        // disabled default constructor
    Brand(const Brand &) = delete;            // disabled copy constructor
    Brand &operator=(const Brand &) = delete; // disabled copy assignment
    Brand &operator=(Brand &&) = default;     // enabled move assignment
    Brand(Brand &&) = delete;                 // disabled move constructor
    ~Brand() = default;

    Brand(BrandType type,
          std::string unique_tm,
          CarRefContainer ref);

    BrandType type() const { return _type; }

    std::string uniqueTm() const { return _unique_tm; }

    CarRefContainer ref() const { return _ref; }

    friend std::ostream &operator<<(std::ostream &os, const Brand &rhs);
    
    
};

#endif // BRAND_H
