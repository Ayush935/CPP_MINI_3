#include "Car.h"
std::ostream &operator<<(std::ostream &os, const Car &rhs) {
    std::string val = "";
    if(rhs._chassis==CarChassisType::CARBON_FIBER){
        val = "CARBON_FIBER";
    }
    else{
        val = "STEEL";
    }
    os << "_seat_count: " << rhs._seat_count
       << " _price: " << rhs._price
       << " _wheel_base: " << rhs._wheel_base
       << " _chassis: " << val;
    return os;
}

Car::Car(int seat_count, float price, float wheel_base, CarChassisType chassis)
    : _seat_count{seat_count},_wheel_base{wheel_base},_chassis{chassis}
{
}