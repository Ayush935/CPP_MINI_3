#ifndef CAR_H
#define CAR_H

#include "CarChassisType.h"
#include <ostream>

class Car
{
private:
    /* data */
    int _seat_count;
    float _price;
    float _wheel_base;
    CarChassisType _chassis;

public:
    Car() = default;                      // disabled default constructor
    Car(const Car &) = default;            // disabled copy constructor
    Car &operator=(const Car &) = default; // disabled copy assignment
    Car &operator=(Car &&) = default;     // enabled move assignment
    Car(Car &&) = default;                 // disabled move constructor
    ~Car() = default;

    Car(int seat_count,
        float price,
        float wheel_base,
        CarChassisType chassis);

    int seatCount() const { return _seat_count; }

    float price() const { return _price; }

    float wheelBase() const { return _wheel_base; }

    CarChassisType chassis() const { return _chassis; }

    friend std::ostream &operator<<(std::ostream &os, const Car &rhs);
};

#endif // CAR_H
