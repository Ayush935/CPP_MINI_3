#ifndef BRANDTYPE_H
#define BRANDTYPE_H

enum class BrandType
{
    CONSUMER,
    SPECIAL_PURPOSE,
    TRANSPORT
};

#endif // BRANDTYPE_H
