#ifndef CARCHASSISTYPE_H
#define CARCHASSISTYPE_H

enum class CarChassisType{
     CARBON_FIBER,
     STEEL
};

#endif // CARCHASSISTYPE_H
