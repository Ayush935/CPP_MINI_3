#include "Brand.h"
std::ostream &operator<<(std::ostream &os, const Brand &rhs) {
    std::string val = "";
    if(rhs._type==BrandType::CONSUMER){
        val ="CONSUMER";
    }
    else if(rhs._type==BrandType::SPECIAL_PURPOSE){
        val = "SPECIAL_PURPOSE";
    }
    else{
        val = "TRANSPORT";
    }
    os << "_type: " << val
       << " _unique_tm: " << rhs._unique_tm
       << " _ref: " ;
       for(CarRef re: rhs._ref){
        os<<re.get();
       }
       
    return os;
}

Brand::Brand(BrandType type, std::string unique_tm, CarRefContainer ref)
    : _type{type},_unique_tm{unique_tm},_ref{ref}
{
}