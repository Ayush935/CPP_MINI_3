#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include "Brand.h"
#include <vector>
#include <memory>
#include "ContainerEmptyDataException.h"
using BrandPtr = std::shared_ptr<Brand>;
using BrandContainer = std::vector<BrandPtr>;
using RegistrationCost = std::vector<float>;
using CarContainer = std::vector<Car>;
using RefCarContainer = std::vector<CarRef>;

void CreateBrandObjects(BrandContainer& brand);
RegistrationCost BrandLicenseRegistrationCost(const BrandContainer&brand);
std::optional<RefCarContainer> CarHavingGivenBrandType(const BrandContainer&brand, const BrandType &type);
std::optional<CarContainer> BrandPriceABoveThresold(const BrandContainer&brand, float thrseold);
void DetailsChassisMinimumPrice(const BrandContainer& brand);
void CarBrandHavingSeatCountAbove4(const BrandContainer& brand);

#endif // FUNCTIONALITIES_H
