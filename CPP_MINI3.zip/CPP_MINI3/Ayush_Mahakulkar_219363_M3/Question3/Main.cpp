#include "Functionalities.h"

int main(){
    BrandContainer brand;
    CreateBrandObjects(brand);
    BrandType type = BrandType::CONSUMER;
    std::future<RegistrationCost> cost = std::async(&BrandLicenseRegistrationCost,std::ref(brand));

    std::future<std::optional<RefCarContainer>> costref = std::async(&CarHavingGivenBrandType,std::ref(brand),std::ref(type));   

    std::future<std::optional<CarContainer>> cont = std::async(&BrandPriceABoveThresold,std::ref(brand),10000);
    
    std::future<void> Chassis = std::async(&DetailsChassisMinimumPrice,std::ref(brand));

    std::future<void> Having = std::async(& CarBrandHavingSeatCountAbove4,std::ref(brand));

    try
    {
        RegistrationCost CostReg = cost.get();
        int count{0};
        for(float reg: CostReg){
            std::cout<<"Brand License Registration Cost "<<count++ <<" "<<reg<<std::endl;
        }

        std::optional<RefCarContainer> ref = costref.get();
        if(ref.has_value()){
            RefCarContainer val = ref.value();

            for(CarRef re: val){
                std::cout<<re.get()<<std::endl;
            }
        }

        std::optional<CarContainer> conti = cont.get();
        if(conti.has_value()){
            CarContainer cc = conti.value();
            for(Car c: cc){
                std::cout<<c<<std::endl;
            }
        }

        Chassis.get();
        Having.get();

    }
    catch(ContainerEmptyException& e)
    {
        std::cerr << e.what() << '\n';
    }
    
}